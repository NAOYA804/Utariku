import React from 'react';

function App() {
  return (
    <div style={{ textAlign: 'center', padding: '2em' }}>
      <h1>🎵 Utariku Music App 🎵</h1>
      <p>ここにあなたの楽曲リストアプリを追加しましょう！</p>
    </div>
  );
}

export default App;
